=== MTDb Updater ===
Contributors: Erick Meza
Tags: debug, debug-bar, debugging, development, developer, performance, profiler, queries, query monitor, rest-api
Requires at least: 3.7
Tested up to: 5.3
Stable tag: 3.5.2
License: GPLv2 or later
Requires PHP: 5.3
